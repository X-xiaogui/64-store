
$(function(){
	$("#img1").click(function(){
		$(".top_1_3").slideDown(500)
	})
	$(".x").click(function(){
		$(".top_1_3").slideUp(500)
	})
})

$(function(){
	$(".sj_1_ul").children("li").click(function(){
			if($(this).children("ul").css("display")=="none"){
				$(this).children("ul").slideDown(500)
				$(this).children("img").css("transform","rotare(45deg)")
			}else{
				$(this).children("ul").slideUp(500)
				$(this).children("img").css("transform","rotare(-45deg)")
				}
		})
	
})


$(function(){
	$(".center_2a").stop().slideDown(2000).children("p")
})
setTimeout(function(){
$(".center_2a").css("background","#fff")
$(".center_2a").children("p").css("color","#000")
$(".center_2a>p").children("span").css("color","#91bde9")
},2500)

//