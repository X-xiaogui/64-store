window.onload=function(){
	var x=document.getElementById("a").innerHTML;
	function jf(){
		x-=45;
		document.getElementById("a").innerHTML=x;
		if(x<=-10000){
			clearInterval(i)
		}
		
	}
	i=setInterval(jf,10)
	
	var y=document.getElementById("b").innerHTML;
	function jf1(){
		y-=45;
		document.getElementById("b").innerHTML=y;
		if(y<=-3691){
			clearInterval(j)
		}
		
	}
	j=setInterval(jf1,10);
	
	var z=document.getElementById("c").innerHTML;
	function jf2(){
		z-=45;
		document.getElementById("c").innerHTML=y;
		if(z<=-12000){
			clearInterval(j1)
		}
		
	}
	j1=setInterval(jf2,10)
	
	var z1=document.getElementById("d").innerHTML;
	function jf4(){
		z1-=1;
		document.getElementById("d").innerHTML=z1;
		if(z1<=-30){
			clearInterval(j6)
		}
		
	}
	j6=setInterval(jf4,50)
}
